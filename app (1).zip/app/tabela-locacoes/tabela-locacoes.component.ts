import { Component, OnInit } from '@angular/core';
import { Locacao } from "../locacao";
import { CrudLocacaoService } from "../crud-locacao.service";

@Component({
  selector: 'app-tabela-locacoes',
  templateUrl: './tabela-locacoes.component.html',
  styleUrls: ['./tabela-locacoes.component.css']
})
export class TabelaLocacoesComponent implements OnInit {
   
  titulo = "Tabela de Locacoes";
  locacoes:Locacao[]=[{codigo:2, cliente:"maria", carro:"Nissan Versa", retirada: "09/09/2017" , entrega: "13/09/2017"}];
  constructor(private servico:CrudLocacaoService) { }
  ngOnInit() {
     this.locacoes = this.servico.getLocacoes(); 
  }

  remover(locacao:Locacao){
    this.servico.removerLocacao(locacao);
  }

}
