import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabelaLocacoesComponent } from './tabela-locacoes.component';

describe('TabelaLocacoesComponent', () => {
  let component: TabelaLocacoesComponent;
  let fixture: ComponentFixture<TabelaLocacoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabelaLocacoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabelaLocacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
