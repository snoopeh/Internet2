import { Injectable } from '@angular/core';
import { Cliente } from './cliente';

@Injectable()
export class CrudClienteService {
  clientes: Cliente[] = [
    {codigo:1, nome:"marcos marcos", cpf: 18003545, telefone: 1546215},
    {codigo:2, nome:"maria mariada", cpf: 20021456, telefone: 2546546}
  ]
  autoIncrement: number=3;

  constructor() { }

  getClientes(){
    return this.clientes;
  }
  adicionarCliente(cliente:Cliente){
    cliente.codigo=this.autoIncrement++;
    this.clientes.push(cliente);
  }
  getClientePorCodigo(codigo:number){
    return(this.clientes.find(cliente => cliente.codigo==codigo));
  }
  removerCliente(cliente:Cliente){
    let indice = this.clientes.indexOf(cliente, 0);
    if (indice > -1){
      this.clientes.splice(indice, 1);
    }
  }
  atualizaCliente(codigo:number, cliente:Cliente){
    let indice = this.clientes.indexOf(this.getClientePorCodigo(codigo), 0);
    this.clientes[indice] = cliente;
  }

}
