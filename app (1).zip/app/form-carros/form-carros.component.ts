import { Component, OnInit } from '@angular/core';
import { CrudLocadoraService } from '../crud-locadora.service';
import { Carro } from "../carro";
import { Router,ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-form-carros',
  templateUrl: './form-carros.component.html',
  styleUrls: ['./form-carros.component.css'],

})
export class FormCarrosComponent implements OnInit {
  titulo = "Cadastro de Carros";
  carro: Carro;
  id: number;

  constructor(private servico:CrudLocadoraService,
              private router:Router,
              private rota: ActivatedRoute) { }

  ngOnInit() { 
    this.id = this.rota.snapshot.params['cod'];
    if(isNaN(this.id))
      this.carro = new Carro(); 
    else{
      this.servico.getCarroPorCodigo(this.id).subscribe((carro:Carro) => {this.carro = carro;})
    }
  }

  salvarCarro(){
    if(isNaN(this.id)){
    this.servico.adicionarCarro(this.carro).subscribe((carro:Carro) => {
      this.carro = new Carro();
      this.router.navigate(['/lista']);      
    });
    }
    else{
      this.servico.atualizaCarro(this.carro).subscribe((carro:Carro) => { this.router.navigate(['/lista']);});
    }
  }

  cancelar() { this.router.navigate(['/lista']); }
}
