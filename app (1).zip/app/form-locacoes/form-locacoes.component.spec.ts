import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormLocacoesComponent } from './form-locacoes.component';

describe('FormLocacoesComponent', () => {
  let component: FormLocacoesComponent;
  let fixture: ComponentFixture<FormLocacoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormLocacoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormLocacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
