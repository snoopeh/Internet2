import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { TabelaCarrosComponent } from './tabela-carros/tabela-carros.component';
import { FormCarrosComponent } from './form-carros/form-carros.component';
import { CrudLocadoraService} from "./crud-locadora.service";
import { TabelaClientesComponent } from './tabela-clientes/tabela-clientes.component';
import { FormClientesComponent } from './form-clientes/form-clientes.component';
import { CrudClienteService} from "./crud-cliente.service";
import { TabelaLocacoesComponent } from './tabela-locacoes/tabela-locacoes.component';
import { FormLocacoesComponent } from './form-locacoes/form-locacoes.component';
import { CrudLocacaoService} from "./crud-locacao.service";
import { RouterModule, Routes } from '@angular/router';




const routes: Routes = [
  {path: '', redirectTo: 'lista', pathMatch: 'full'},
  {path: 'lista', component: TabelaCarrosComponent },
  {path: 'edicao/:cod', component: FormCarrosComponent},
  {path: 'novo', component: FormCarrosComponent},
  {path: 'listac', component:TabelaClientesComponent},
  {path: 'edicaoc/:cod', component: FormClientesComponent},
  {path: 'novoc', component: FormClientesComponent},
  {path: 'listal', component:TabelaLocacoesComponent},
  {path: 'edicaol/:cod', component: FormLocacoesComponent},
  {path: 'novol', component: FormLocacoesComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    TabelaCarrosComponent,
    TabelaClientesComponent,
    TabelaLocacoesComponent,
    FormCarrosComponent,
    FormClientesComponent,
    FormLocacoesComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [CrudLocadoraService,CrudClienteService,CrudLocacaoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
