import { Component, OnInit } from '@angular/core';
import { Cliente } from "../cliente";
import { CrudClienteService } from "../crud-cliente.service";

@Component({
  selector: 'app-tabela-clientes',
  templateUrl: './tabela-clientes.component.html',
  styleUrls: ['./tabela-clientes.component.css'],
})
export class TabelaClientesComponent implements OnInit {
  titulo = "Tabela de Clientes";
  clientes:Cliente[]=[{codigo:1, nome:"Marcos March", cpf:100000000, telefone:99999999}];
  constructor(private servico:CrudClienteService) { }
  ngOnInit() {
    this.clientes = this.servico.getClientes(); 
  }
  remover(cliente:Cliente){
    this.servico.removerCliente(cliente);
  }
}
