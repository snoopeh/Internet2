import { TestBed, inject } from '@angular/core/testing';

import { CrudLocadoraService } from './crud-locadora.service';

describe('CrudLocadoraService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CrudLocadoraService]
    });
  });

  it('should be created', inject([CrudLocadoraService], (service: CrudLocadoraService) => {
    expect(service).toBeTruthy();
  }));
});
