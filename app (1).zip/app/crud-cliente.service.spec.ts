import { TestBed, inject } from '@angular/core/testing';

import { CrudClienteService } from './crud-cliente.service';

describe('CrudClienteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CrudClienteService]
    });
  });

  it('should be created', inject([CrudClienteService], (service: CrudClienteService) => {
    expect(service).toBeTruthy();
  }));
});
