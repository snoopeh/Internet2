import { Component, OnInit } from '@angular/core';
import { Carro } from "../carro";
import { CrudLocadoraService} from "../crud-locadora.service"

@Component({
  selector: 'app-tabela-carros',
  templateUrl: './tabela-carros.component.html',
  styleUrls: ['./tabela-carros.component.css']
})
export class TabelaCarrosComponent implements OnInit {
  titulo = "Tabela de Carros";
  carros:Carro[]=[];
  constructor(private servico:CrudLocadoraService) { }
  ngOnInit() {
    this.atualizaTabela();
  }

  atualizaTabela(){
    this.servico.getCarros().subscribe((carros:Carro[]) => this.carros = carros);
  }

  remover(carro:Carro){
    this.servico.removerCarro(carro).subscribe((carror:Carro) => {this.atualizaTabela();});
  }
}
