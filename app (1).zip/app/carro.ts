export class Carro {
    id: number;
    nome: string;
    diaria: number;
}
