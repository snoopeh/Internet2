import { Injectable } from '@angular/core';
import { Carro } from "./carro";
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class CrudLocadoraService {
  carros: Carro[] = []
  uri="http://localhost:8080/AppMotoresBD/api/carro";
  autoIncrement: number=3;

  constructor(private http:Http) { }

  getCarros():Observable<Carro[]>{
    return this.http.get(this.uri)
    .map((res:Response)=>res.json())
    .catch((erro:any) => Observable.throw(erro));
  }
  adicionarCarro(carro:Carro):Observable<Carro>{
    let bodyString = JSON.stringify(carro);
    let cabecalho = new Headers({'Content-Type':'application/json'});
    let options = new RequestOptions({headers:cabecalho});
    return this.http.post(this.uri, bodyString, options)
      .map((res:Response) => {})
      .catch((erro:any) => Observable.throw(erro));
  }
  getCarroPorCodigo(id:number):Observable<Carro>{
    let url = this.uri + '/' + id;
    return this.http.get(url)
    .map((res:Response)=>res.json())
    .catch((erro:any) => Observable.throw(erro));
  }
  removerCarro(carro:Carro):Observable<Carro>{
    let url = this.uri + '/' + carro.id;
    return this.http.delete(url)
      .map((res:Response) => {})
      .catch((erro:any) => Observable.throw(erro));
    }
  
  atualizaCarro(carro:Carro):Observable<Carro>{
    let url = this.uri + '/' + carro.id;
    
    let body = JSON.stringify(carro);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

     return this.http.put(url, body, options)
    .map((res:Response) => {})
    .catch((erro:any) => Observable.throw(erro));
  }
}

