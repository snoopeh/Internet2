export class Locacao {
    codigo: number;
    cliente: string;
    carro: string;
    retirada: string;
    entrega: string;
}
