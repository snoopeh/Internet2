import { Component, OnInit } from '@angular/core';
import { CrudClienteService } from '../crud-cliente.service';
import { Cliente } from "../cliente";
import { Router,ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-form-clientes',
  templateUrl: './form-clientes.component.html',
  styleUrls: ['./form-clientes.component.css'],
})
export class FormClientesComponent implements OnInit {
    titulo = "Cadastro de Clientes";
    cliente: Cliente;
    codigo: number;
  
    constructor(private servico:CrudClienteService,
                private router:Router,
                private rota: ActivatedRoute) { }
  
    ngOnInit() { 
      this.codigo = this.rota.snapshot.params['cod'];
      if(isNaN(this.codigo))
        this.cliente = new Cliente(); 
      else{
        this.cliente = Object.assign({},
          this.servico.getClientePorCodigo(this.codigo));
      }
    }
  
    salvarCliente(){
      if(isNaN(this.codigo)){
      this.servico.adicionarCliente(this.cliente);
      this.cliente = new Cliente();
      }
      else{
        this.servico.atualizaCliente(this.codigo, this.cliente)
      }
      this.router.navigate(['/listac']);
    }
  
    cancelar() { this.router.navigate(['/listac']); }
}
  


