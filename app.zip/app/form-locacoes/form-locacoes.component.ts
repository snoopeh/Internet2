import { Component, OnInit } from '@angular/core';
import { CrudLocacaoService } from '../crud-locacao.service';
import { Locacao } from "../locacao";
import { Router,ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-form-locacoes',
  templateUrl: './form-locacoes.component.html',
  styleUrls: ['./form-locacoes.component.css']
})
export class FormLocacoesComponent implements OnInit {
  
  titulo = "Cadastro de Locacoes";
  locacao: Locacao;
  codigo: number;

  constructor(private servico:CrudLocacaoService,
              private router:Router,
              private rota: ActivatedRoute) { }

  ngOnInit() { 
    this.codigo = this.rota.snapshot.params['cod'];
    if(isNaN(this.codigo))
      this.locacao = new Locacao(); 
    else{
      this.locacao = Object.assign({},
        this.servico.getLocacaoPorCodigo(this.codigo));
    }
  }

  salvarLocacao(){
    if(isNaN(this.codigo)){
    this.servico.adicionarLocacao(this.locacao);
    this.locacao = new Locacao();
    }
    else{
      this.servico.atualizaLocacao(this.codigo, this.locacao)
    }
    this.router.navigate(['/listal']);
  }

  cancelar() { this.router.navigate(['/listal']); }
}
