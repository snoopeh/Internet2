import { Injectable } from '@angular/core';
import { Locacao } from "./locacao";

@Injectable()
export class CrudLocacaoService {

  locacoes: Locacao[] = [
    {codigo:1, cliente:"marcos", carro:"Nissan March", retirada: "02/09/2017" , entrega: "05/09/2017"},
    {codigo:2, cliente:"maria", carro:"Nissan Versa", retirada: "09/09/2017" , entrega: "13/09/2017"}
  ]
  autoIncrement: number=3;


  constructor() { }
  getLocacoes(){
    return this.locacoes;
  }
  adicionarLocacao(locacao:Locacao){
    locacao.codigo=this.autoIncrement++;
    this.locacoes.push(locacao);
  }
  getLocacaoPorCodigo(codigo:number){
    return(this.locacoes.find(locacao => locacao.codigo==codigo));
  }
  removerLocacao(locacao:Locacao){
    let indice = this.locacoes.indexOf(locacao, 0);
    if (indice > -1){
      this.locacoes.splice(indice, 1);
    }
  }
  atualizaLocacao(codigo:number, locacao:Locacao){
    let indice = this.locacoes.indexOf(this.getLocacaoPorCodigo(codigo), 0);
    this.locacoes[indice] = locacao;
  }
}
