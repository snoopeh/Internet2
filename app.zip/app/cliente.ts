export class Cliente {
    codigo: number;
    nome: string;
    cpf: number;
    telefone:number;
}
