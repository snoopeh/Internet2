import { Injectable } from '@angular/core';
import { Carro } from "./carro";

@Injectable()
export class CrudLocadoraService {
  carros: Carro[] = [
    {codigo:1, nome:"Nissan March", diaria: 180.00},
    {codigo:2, nome:"Nissan Versa", diaria: 200.00}
  ]
  autoIncrement: number=3;

  constructor() { }
  getCarros(){
    return this.carros;
  }
  adicionarCarro(carro:Carro){
    carro.codigo=this.autoIncrement++;
    this.carros.push(carro);
  }
  getCarroPorCodigo(codigo:number){
    return(this.carros.find(carro => carro.codigo==codigo));
  }
  removerCarro(carro:Carro){
    let indice = this.carros.indexOf(carro, 0);
    if (indice > -1){
      this.carros.splice(indice, 1);
    }
  }
  atualizaCarro(codigo:number, carro:Carro){
    let indice = this.carros.indexOf(this.getCarroPorCodigo(codigo), 0);
    this.carros[indice] = carro;
  }
}
