import { TestBed, inject } from '@angular/core/testing';

import { CrudLocacaoService } from './crud-locacao.service';

describe('CrudLocacaoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CrudLocacaoService]
    });
  });

  it('should be created', inject([CrudLocacaoService], (service: CrudLocacaoService) => {
    expect(service).toBeTruthy();
  }));
});
