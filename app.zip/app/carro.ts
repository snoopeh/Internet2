export class Carro {
    codigo: number;
    nome: string;
    diaria: number;
}
