import { Component, OnInit } from '@angular/core';
import { CrudLocadoraService } from '../crud-locadora.service';
import { Carro } from "../carro";
import { Router,ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-form-carros',
  templateUrl: './form-carros.component.html',
  styleUrls: ['./form-carros.component.css'],

})
export class FormCarrosComponent implements OnInit {
  titulo = "Cadastro de Carros";
  carro: Carro;
  codigo: number;

  constructor(private servico:CrudLocadoraService,
              private router:Router,
              private rota: ActivatedRoute) { }

  ngOnInit() { 
    this.codigo = this.rota.snapshot.params['cod'];
    if(isNaN(this.codigo))
      this.carro = new Carro(); 
    else{
      this.carro = Object.assign({},
        this.servico.getCarroPorCodigo(this.codigo));
    }
  }

  salvarCarro(){
    if(isNaN(this.codigo)){
    this.servico.adicionarCarro(this.carro);
    this.carro = new Carro();
    }
    else{
      this.servico.atualizaCarro(this.codigo, this.carro)
    }
    this.router.navigate(['/lista']);
  }

  cancelar() { this.router.navigate(['/lista']); }
}
