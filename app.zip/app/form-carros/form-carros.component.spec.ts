import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormCarrosComponent } from './form-carros.component';

describe('FormCarrosComponent', () => {
  let component: FormCarrosComponent;
  let fixture: ComponentFixture<FormCarrosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormCarrosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormCarrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
