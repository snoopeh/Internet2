window.onload = function(){
    setInterval(buscaMotores,5000);    
}

function buscaMotores(){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            //alert(this.responseText);
            var motores = JSON.parse(this.responseText);
            carregaMotores(motores);

        }
    }

    xhttp.open("GET","http://localhost:8080/AppMotoresBD/api/motor",true);
    xhttp.send();
}

function carregaMotores(motores){
    var str="";
    for(var i=0; i<motores.length; i++){
        console.log(motores[i]);
        str += "<dl>";
        str += "<dd>";
        str += "<figure>";
        str += "<img src=\"img/motor-1.jpg\" alt=\""+motores[i].nome+"\" />";
        str += "</figure>";
        str += "</dd>";
        str += "<dt>";
        str += "<a href=\"#\">"+motores[i].nome+" </a>";
        str += "</dt>";
        str += "<dd>";
        str += motores[i].descricao;
        str += "</dd>";
        str += "<dd>";
        str += "<strong> Uso: </strong> "+motores[i].uso;
        str += "</dd>";
        str += "</dl>";  
    }

    //var main = document.getElementsByTagName("main");
    //main[0].innerHTML = motores[0].nome;
    document.querySelector("main").innerHTML = str;
   
}