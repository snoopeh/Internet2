package dao;

import entidade.Motor;
import java.util.List;

public interface MotorDao {
    public void salvar(Motor m);
    public void deletar(int id);
    public void deletar(Motor m);
    public void atualizar(Motor m);    
    public List<Motor> listar();
    public Motor buscarPorId(int id);
}
