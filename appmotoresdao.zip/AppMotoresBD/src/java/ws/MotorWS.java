/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import dao.MotorDao;
import dao.MotorDaoBd;
import entidade.Motor;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.InternalServerErrorException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author lhries
 */
@Path("motor")
public class MotorWS {
    
    @Context
    private UriInfo context;

    /**
     * Creates a new instance of MotorWS
     */
    public MotorWS() {
    }

    /**
     * Retrieves representation of an instance of ws.MotorWS
     * @return an instance of entidade.Motor
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Motor> getMotores() {
        MotorDao motorDao = new MotorDaoBd();
        return motorDao.listar();
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{id}")
    public Motor getMotorPorId(@PathParam("id") int id){
        MotorDao motorDao = new MotorDaoBd();
        return motorDao.buscarPorId(id);
    }

    /**
     * PUT method for updating or creating an instance of MotorWS
     * @param motor representation for the resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void inserirMotor(Motor motor, 
            @Context HttpServletResponse response) {        
        
        MotorDao motorDao = new MotorDaoBd();
        motorDao.salvar(motor);
        response.setStatus(HttpServletResponse.SC_CREATED);
        try {
            response.flushBuffer();
        } catch (IOException ex) {
            throw new InternalServerErrorException();
        }
    }
}
