package dao;

import ws.MotorWS;
import entidade.Motor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MotorDaoBd implements MotorDao {

    @Override
    public void salvar(Motor motor) {
        try {
            Connection conexao = ConnectionFactory.getConnection();

            String sql = "INSERT INTO motor (nome,diaria) "
                    + "VALUES (?,?)";
            PreparedStatement comando = conexao.prepareStatement(sql);

            comando.setString(1, motor.getNome());
            comando.setInt(2, motor.getDiaria());
            

            comando.executeUpdate();
            
            

            comando.close();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(MotorWS.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void deletar(int id) {
        try {
            Connection conexao = ConnectionFactory.getConnection();

            String sql = "DELETE FROM motor WHERE id=?";

            PreparedStatement comando = conexao.prepareStatement(sql);
            comando.setInt(1, id);

            comando.executeUpdate();

            comando.close();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(MotorDaoBd.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void deletar(Motor m) {
        this.deletar(m.getId());
    }

    @Override
    public void atualizar(Motor m) {
        try {
            Connection conexao = ConnectionFactory.getConnection();

            String sql = "UPDATE motor "
                    + "SET nome=?, diaria=? "
                    + "WHERE id=?";

            PreparedStatement comando = conexao.prepareStatement(sql);
            comando.setString(1, m.getNome());
            comando.setInt(2, m.getDiaria());
            comando.setInt(3, m.getId());

            comando.executeUpdate();

            comando.close();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(MotorDaoBd.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Motor> listar() {
        List<Motor> listaMotores = new ArrayList<>();
        try {
            Connection conexao = ConnectionFactory.getConnection();

            String sql = "SELECT * FROM motor";
            PreparedStatement comando = conexao.prepareStatement(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                int diaria = resultado.getInt("diaria");

                Motor motor = new Motor(id, nome, diaria);
                listaMotores.add(motor);
            }

            comando.close();
            conexao.close();

        } catch (SQLException ex) {
            Logger.getLogger(MotorWS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaMotores;
    }

    @Override
    public Motor buscarPorId(int id) {
        try {
            Connection conexao = ConnectionFactory.getConnection();

            String sql = "SELECT * FROM motor WHERE id=?";

            Motor motor = null;

            PreparedStatement comando = conexao.prepareStatement(sql);
            comando.setInt(1, id);

            ResultSet resultado = comando.executeQuery();
            if (resultado.next()) {
                String nome = resultado.getString("nome");
                int diaria = resultado.getInt("diaria");
                motor = new Motor(id, nome, diaria);
            }

            comando.close();
            conexao.close();

            return motor;

        } catch (SQLException ex) {
            Logger.getLogger(MotorDaoBd.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
