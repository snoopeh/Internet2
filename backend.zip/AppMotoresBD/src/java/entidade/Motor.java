package entidade;

/**
 *
 * @author lhries
 */
public class Motor {
    private int id, diaria;
    private String nome;
    
    public Motor(){
        
    }

    public Motor(String nome, int diaria) {
        this.nome = nome;
        this.diaria = diaria;
    }

    public Motor(int id, String nome, int diaria) {
        this.id = id;
        this.nome = nome;
        this.diaria = diaria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDiaria() {
        return diaria;
    }

    public void setDiaria(int diaria) {
        this.diaria = diaria;
    }
}
